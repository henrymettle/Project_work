package com.example.yoporth

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.location.Geocoder
import android.location.Location
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Bundle
import android.os.Environment
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.yoporth.databinding.ActivityMainBinding
import com.example.yoporth.Constants.LABELS_PATH
import com.example.yoporth.Constants.MODEL_PATH
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.common.util.concurrent.ListenableFuture
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.use

class MainActivity : AppCompatActivity(), Detector.DetectorListener {
    private lateinit var binding: ActivityMainBinding
    private val isFrontCamera = false

    private var preview: Preview? = null
    private var imageAnalyzer: ImageAnalysis? = null
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var detector: Detector? = null

    private lateinit var cameraProviderFuture: ListenableFuture<ProcessCameraProvider>
    private lateinit var cameraExecutor: ExecutorService

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var lastGeotagTime: Long = 0
    private val GEOTAG_INTERVAL = 5000 

    private var totalPotholes = 0
    private var totalDistance = 0.0
    private var lastLocation: Location? = null
    private lateinit var currentSessionId: String

    private lateinit var soundPool: SoundPool
    private var beepSoundId: Int = 0
    private var lastBeepTime: Long = 0
    private val BEEP_INTERVAL = 1000 // 1 second cooldown for sound

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        currentSessionId = UUID.randomUUID().toString()

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.buttonStop.setOnClickListener {
            saveSessionAndFinish()
        }

        cameraExecutor = Executors.newSingleThreadExecutor()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        initSoundPool()

        if (allPermissionsGranted()) {
            initDetector()
            startCamera()
            startLocationUpdates()
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }
    }

    private fun initSoundPool() {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        
        soundPool = SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(audioAttributes)
            .build()
        
        try {
            val assetFileDescriptor = assets.openFd("beep.wav")
            beepSoundId = soundPool.load(assetFileDescriptor, 1)
        } catch (e: Exception) {
            Log.e(TAG, "Error loading beep sound", e)
        }
    }

    private fun playBeep() {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastBeepTime >= BEEP_INTERVAL && beepSoundId != 0) {
            soundPool.play(beepSoundId, 1f, 1f, 0, 0, 1f)
            lastBeepTime = currentTime
        }
    }

    private fun saveSessionAndFinish() {
        val now = Date()
        val dateFormat = SimpleDateFormat("MMMM dd,yyyy", Locale.getDefault())
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        
        val locationName = lastLocation?.let {
            try {
                val geocoder = Geocoder(this, Locale.getDefault())
                val addresses = geocoder.getFromLocation(it.latitude, it.longitude, 1)
                if (!addresses.isNullOrEmpty()) {
                    val address = addresses[0]
                    "${address.locality ?: "Unknown"}, ${address.countryName ?: "Ghana"}"
                } else {
                    "Unknown Location"
                }
            } catch (e: Exception) {
                "Tema, Ghana"
            }
        } ?: "Tema, Ghana"

        // Use the sum of boxes across all detections for this session
        val sessionDetections = DetectionStorage.getDetectionsForSession(currentSessionId)
        val actualPotholeCount = sessionDetections.sumOf { it.boxCount }

        val session = DetectionSession(
            id = currentSessionId,
            date = dateFormat.format(now),
            time = timeFormat.format(now),
            distance = String.format("%.2f km", totalDistance),
            totalPotholes = actualPotholeCount,
            locationName = locationName,
            timestamp = System.currentTimeMillis()
        )
        
        DetectionStorage.addSession(this, session)
        
        val intent = Intent(this, SavedReportsActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun initDetector() {
        if (detector == null) {
            detector = Detector(baseContext, MODEL_PATH, LABELS_PATH, this)
            detector?.setup()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000)
            .setWaitForAccurateLocation(false)
            .setMinUpdateIntervalMillis(2000)
            .setMaxUpdateDelayMillis(10000)
            .build()

        fusedLocationClient.requestLocationUpdates(locationRequest, object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                for (location in locationResult.locations) {
                    if (lastLocation != null) {
                        val distance = lastLocation!!.distanceTo(location)
                        totalDistance += distance.toDouble() / 1000.0 // convert to km
                        binding.textViewDistanceLabel.text = String.format("Distance: %.1f km", totalDistance)
                    }
                    lastLocation = location
                }
            }
        }, mainLooper)
    }

    override fun onResume() {
        super.onResume()
        if (allPermissionsGranted()) {
            initDetector()
        }
    }

    override fun onPause() {
        super.onPause()
        cameraProvider?.unbindAll()
    }

    override fun onDestroy() {
        super.onDestroy()
        detector?.clear()
        detector = null
        cameraExecutor.shutdown()
        soundPool.release()
    }

    private fun startCamera() {
        cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCameraUseCases() {
        val cameraProvider = cameraProvider ?: return
        val rotation = binding.viewFinder.display.rotation
        val cameraSelector = CameraSelector
            .Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .build()
        
        preview = Preview.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .setTargetRotation(rotation)
            .build()
            
        imageAnalyzer = ImageAnalysis.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setTargetRotation(binding.viewFinder.display.rotation)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()

        imageAnalyzer?.setAnalyzer(cameraExecutor) { imageProxy ->
            val bitmapBuffer = Bitmap.createBitmap(imageProxy.width, imageProxy.height, Bitmap.Config.ARGB_8888)
            imageProxy.use { bitmapBuffer.copyPixelsFromBuffer(imageProxy.planes[0].buffer) }
            
            val matrix = Matrix().apply {
                postRotate(imageProxy.imageInfo.rotationDegrees.toFloat())
                if (isFrontCamera) {
                    postScale(-1f, 1f, imageProxy.width.toFloat(), imageProxy.height.toFloat())
                }
            }
            val rotatedBitmap = Bitmap.createBitmap(bitmapBuffer, 0, 0, bitmapBuffer.width, bitmapBuffer.height, matrix, true)

            detector?.detectAsync(rotatedBitmap)
            imageProxy.close()
        }

        try {
            cameraProvider.unbindAll()
            camera = cameraProvider.bindToLifecycle(
                this,
                cameraSelector,
                preview,
                imageAnalyzer
            )
            preview?.setSurfaceProvider(binding.viewFinder.surfaceProvider)
        } catch(exc: Exception) {
            Log.e(TAG, "Use case binding failed", exc)
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private const val TAG = "Camera"
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    }

    override fun onEmptyDetect() {
        runOnUiThread {
            binding.overlay.setResults(emptyList())
            binding.inferenceTime.text = ""
        }
    }

    override fun onDetect(boundingBoxes: List<BoundingBox>, inferenceTime: Long, frame: Bitmap) {
        runOnUiThread {
            binding.inferenceTime.text = "${inferenceTime}ms"
            binding.overlay.setResults(boundingBoxes)
            
            if (boundingBoxes.isNotEmpty()) {
                playBeep()
                
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastGeotagTime >= GEOTAG_INTERVAL) {
                    geotagAndSave(boundingBoxes, frame)
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun geotagAndSave(boundingBoxes: List<BoundingBox>, bitmap: Bitmap) {
        val currentTime = System.currentTimeMillis()
        if (allPermissionsGranted()) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                location?.let {
                    val imageWithBoundingBoxes = drawBoundingBoxes(bitmap, boundingBoxes)
                    val imagePath = saveImageToInternalStorage(imageWithBoundingBoxes)
                    val detection = DetectionLocation(
                        it.latitude, 
                        it.longitude, 
                        currentTime, 
                        boundingBoxes.first().clsName, 
                        imagePath, 
                        currentSessionId,
                        boundingBoxes.size
                    )
                    DetectionStorage.addDetection(this, detection)
                    
                    // Update total count based on sum of boxes
                    val sessionDetections = DetectionStorage.getDetectionsForSession(currentSessionId)
                    totalPotholes = sessionDetections.sumOf { d -> d.boxCount }
                    binding.textViewPotholeCount.text = totalPotholes.toString()
                    
                    lastGeotagTime = currentTime
                }
            }
        }
    }

    private fun drawBoundingBoxes(bitmap: Bitmap, boundingBoxes: List<BoundingBox>): Bitmap {
        val mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(mutableBitmap)
        val paint = Paint().apply {
            color = Color.RED
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 40f
            style = Paint.Style.FILL
        }

        boundingBoxes.forEach { box ->
            val left = box.x1 * mutableBitmap.width
            val top = box.y1 * mutableBitmap.height
            val right = box.x2 * mutableBitmap.width
            val bottom = box.y2 * mutableBitmap.height
            canvas.drawRect(left, top, right, bottom, paint)
            canvas.drawText(box.clsName, left, top - 10, textPaint)
        }
        return mutableBitmap
    }

    private fun saveImageToInternalStorage(bitmap: Bitmap): String? {
        val filename = "detection_${System.currentTimeMillis()}.jpg"
        val directory = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Potholes")
        if (!directory.exists()) directory.mkdirs()
        
        val file = File(directory, filename)
        return try {
            val out = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            out.flush()
            out.close()
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                initDetector()
                startCamera()
                startLocationUpdates()
            }
        }
    }
}