package com.example.yoporth

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.yoporth.databinding.ActivitySavedReportsBinding

class SavedReportsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySavedReportsBinding
    private lateinit var sessionAdapter: SessionsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySavedReportsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Reports"
        binding.toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        setupRecyclerViews()
        loadData()
    }

    private fun setupRecyclerViews() {
        sessionAdapter = SessionsAdapter(emptyList()) { session ->
            val intent = Intent(this, MapsActivity::class.java)
            intent.putExtra("SESSION_ID", session.id)
            startActivity(intent)
        }
        binding.recyclerViewReports.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewReports.adapter = sessionAdapter
    }

    private fun loadData() {
        val sessions = DetectionStorage.getSessions()
        if (sessions.isEmpty()) {
            binding.recyclerViewReports.visibility = View.GONE
        } else {
            binding.recyclerViewReports.visibility = View.VISIBLE
            sessionAdapter.updateData(sessions)
        }
    }
}