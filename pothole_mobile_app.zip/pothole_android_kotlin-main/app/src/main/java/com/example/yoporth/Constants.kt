package com.example.yoporth

object Constants {
//    const val MODEL_PATH = "model.tflite"
const val MODEL_PATH = "pothole.tflite"
    const val LABELS_PATH = "labels.txt"
}
