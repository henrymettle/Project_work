package com.example.yoporth

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class GalleryAnalysisActivity : AppCompatActivity(), Detector.DetectorListener {

    private lateinit var detector: Detector
    private lateinit var imageView: ImageView
    private lateinit var overlayView: OverlayViewGallery
    private lateinit var inferenceTimeTextView: TextView
    private lateinit var placeholderText: TextView
    private lateinit var selectImageButton: Button
    private lateinit var takePhotoButton: Button
    private lateinit var toolbar: Toolbar

    private var imageBitmap: Bitmap? = null
    private var detectorInitialized = false
    private var photoUri: Uri? = null
    private var isCameraCapture = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery_analysis)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Image Detection"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        imageView = findViewById(R.id.photo_image_view)
        overlayView = findViewById(R.id.overlay_view)
        inferenceTimeTextView = findViewById(R.id.inference_time_text)
        placeholderText = findViewById(R.id.placeholder_text)
        selectImageButton = findViewById(R.id.select_image_button)
        takePhotoButton = findViewById(R.id.take_photo_button)

        try {
            detector = Detector(
                context = this,
                modelPath = Constants.MODEL_PATH,
                labelPath = Constants.LABELS_PATH,
                detectorListener = this
            )
            detector.setup()
            detectorInitialized = true
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "ERROR: Failed to load detection model", Toast.LENGTH_LONG).show()
            selectImageButton.isEnabled = false
            takePhotoButton.isEnabled = false
            return
        }

        selectImageButton.setOnClickListener {
            if (detectorInitialized) {
                isCameraCapture = false
                checkGalleryPermissionsAndLaunch()
            }
        }

        takePhotoButton.setOnClickListener {
            if (detectorInitialized) {
                isCameraCapture = true
                checkCameraPermissionsAndLaunch()
            }
        }
    }

    private fun checkGalleryPermissionsAndLaunch() {
        val permission = if (android.os.Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            launchGallery()
        } else {
            requestGalleryPermissionLauncher.launch(permission)
        }
    }

    private fun checkCameraPermissionsAndLaunch() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            launchCamera()
        } else {
            requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private val requestGalleryPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) launchGallery()
            else Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
        }

    private val requestCameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) launchCamera()
            else Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
        }

    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                result.data?.data?.let { loadImageAndRunDetection(it) }
            }
        }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                photoUri?.let { uri ->
                    loadImageAndRunDetection(uri)
                }
            }
        }

    private fun launchGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(intent)
    }

    private fun launchCamera() {
        val photoFile: File? = try {
            createImageFile()
        } catch (ex: Exception) {
            null
        }
        
        photoFile?.also {
            photoUri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                it
            )
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
            cameraLauncher.launch(intent)
        }
    }

    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir)
    }

    private fun saveBitmapToGallery(bitmap: Bitmap) {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "PotholeDetected_${timeStamp}.jpg"
        
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES)
            }
        }

        val resolver = contentResolver
        val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
        
        imageUri?.let { targetUri ->
            resolver.openOutputStream(targetUri).use { outputStream ->
                if (outputStream != null) {
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                }
            }
            Toast.makeText(this, "Detection result saved to gallery", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadImageAndRunDetection(imageUri: Uri) {
        if (!detectorInitialized) return

        overlayView.clear()
        inferenceTimeTextView.text = "Inference Time: --ms"
        placeholderText.visibility = View.GONE

        imageView.scaleType = ImageView.ScaleType.FIT_CENTER
        imageView.setImageURI(imageUri)

        lifecycleScope.launch {
            imageBitmap = loadBitmapFromUri(imageUri)
            imageBitmap?.let { runDetection(it) }
        }
    }

    private suspend fun loadBitmapFromUri(uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            BitmapFactory.decodeStream(inputStream)
        } catch (e: Exception) {
            null
        }
    }

    private fun runDetection(bitmap: Bitmap) {
        detector.detectAsync(bitmap)
    }

    override fun onEmptyDetect() {
        overlayView.clear()
        inferenceTimeTextView.text = "Inference Time: --ms"
        Toast.makeText(this, "No potholes detected.", Toast.LENGTH_SHORT).show()
        
        if (isCameraCapture && imageBitmap != null) {
            saveBitmapToGallery(imageBitmap!!)
        }
    }

    override fun onDetect(boundingBoxes: List<BoundingBox>, inferenceTime: Long, frame: Bitmap) {
        imageView.post {
            val originalWidth = imageBitmap?.width ?: 1
            val originalHeight = imageBitmap?.height ?: 1
            
            // 1. Create matrix that scales normalized [0-1] to [Original Image Pixels]
            val normalizationMatrix = Matrix()
            normalizationMatrix.postScale(originalWidth.toFloat(), originalHeight.toFloat())

            // 2. Create matrix that scales [Original Image Pixels] to [Screen Pixels (FIT_CENTER)]
            val screenMatrix = getTransformationMatrix(
                w = originalWidth,
                h = originalHeight,
                tw = imageView.width,
                th = imageView.height
            )

            // 3. Combine matrices: Normalized -> Original Pixels -> Screen Pixels
            val finalMatrix = Matrix()
            finalMatrix.postConcat(normalizationMatrix)
            finalMatrix.postConcat(screenMatrix)

            // 4. Apply to bounding boxes for UI Display
            val scaledBoxes = boundingBoxes.map { it.scaleAndMove(finalMatrix) }
            overlayView.setResults(scaledBoxes)
            inferenceTimeTextView.text = "Inference Time: $inferenceTime ms"

            // 5. Save detection result to gallery (for both Camera and Gallery picks)
            if (imageBitmap != null) {
                val resultBitmap = drawBoundingBoxesOnBitmap(imageBitmap!!, boundingBoxes)
                saveBitmapToGallery(resultBitmap)
            }
        }
    }

    private fun drawBoundingBoxesOnBitmap(originalBitmap: Bitmap, boxes: List<BoundingBox>): Bitmap {
        val bitmap = originalBitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bitmap)
        val paint = Paint().apply {
            color = Color.RED
            style = Paint.Style.STROKE
            strokeWidth = (bitmap.width / 100f).coerceAtLeast(4f) // Dynamic stroke width
            isAntiAlias = true
        }
        
        val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = (bitmap.width / 25f).coerceAtLeast(20f) // Dynamic text size
            isAntiAlias = true
            style = Paint.Style.FILL
        }

        val textBackgroundPaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.FILL
        }

        for (box in boxes) {
            val left = box.x1 * bitmap.width
            val top = box.y1 * bitmap.height
            val right = box.x2 * bitmap.width
            val bottom = box.y2 * bitmap.height
            
            canvas.drawRect(left, top, right, bottom, paint)
            
            val label = "${box.clsName} ${(box.cnf * 100).toInt()}%"
            val textWidth = textPaint.measureText(label)
            val textHeight = textPaint.fontMetrics.descent - textPaint.fontMetrics.ascent
            
            canvas.drawRect(left, top - textHeight, left + textWidth + 10f, top, textBackgroundPaint)
            canvas.drawText(label, left + 5f, top - textPaint.fontMetrics.descent, textPaint)
        }
        
        return bitmap
    }

    private fun getTransformationMatrix(w: Int, h: Int, tw: Int, th: Int): Matrix {
        val matrix = Matrix()
        if (w <= 0 || h <= 0 || tw <= 0 || th <= 0) return matrix
        
        val scale = min(tw.toFloat() / w, th.toFloat() / h)
        val dx = (tw - w * scale) / 2f
        val dy = (th - h * scale) / 2f
        
        matrix.postScale(scale, scale)
        matrix.postTranslate(dx, dy)
        return matrix
    }

    override fun onDestroy() {
        super.onDestroy()
        if (detectorInitialized) detector.clear()
    }
}