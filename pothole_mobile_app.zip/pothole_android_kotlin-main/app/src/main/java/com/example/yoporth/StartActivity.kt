package com.example.yoporth

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import com.example.yoporth.databinding.ActivityStartBinding

class StartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStartBinding
    private lateinit var toggle: ActionBarDrawerToggle

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        val locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false || 
                             permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        
        if (cameraGranted && locationGranted) {
            startMainActivity()
        } else {
            Toast.makeText(this, "Camera and Location permissions are required for real-time detection.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        DetectionStorage.init(this)
        
        binding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.app_name)

        toggle = ActionBarDrawerToggle(this, binding.drawerLayout, binding.toolbar, R.string.open, R.string.close)
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        binding.navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_saved_reports -> {
                    startActivity(Intent(this, SavedReportsActivity::class.java))
                }
                R.id.nav_help -> {
                    showHelpDialog()
                }
                R.id.nav_about_us -> {
                    showAboutUsDialog()
                }
                R.id.nav_contact_support -> {
                    showContactSupportDialog()
                }
            }
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        binding.buttonOpenCamera.setOnClickListener {
            if (allPermissionsGranted()) {
                startMainActivity()
            } else {
                requestPermissionLauncher.launch(REQUIRED_PERMISSIONS)
            }
        }

        binding.buttonOpenGallery.setOnClickListener {
            startGalleryAnalysisActivity()
        }
    }

    private fun showContactSupportDialog() {
        val supportText = """
            If you need assistance or encounter any issues while using the app, please contact our support team.

            Phone: +233 533 688 612
            Email: henrymettle84@gmail.com

            When contacting support, kindly provide:
            • A brief description of the issue
            • Your device model and operating system
            • The date and time the issue occurred

            We are committed to responding promptly and improving your experience.
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Contact Support")
            .setMessage(supportText)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showHelpDialog() {
        val helpText = """
            Welcome to the Pothole Detection App. Follow the steps below to use the app correctly and get accurate results.

            1. Phone Placement (Important)
            Place your phone securely on a dashboard phone holder.
            Ensure the phone is firmly fixed and does not shake freely.
            Do not hold the phone in your hand while driving.

            2. Starting Detection
            Open the app and tap Start Detection.
            Enable GPS and required permissions when prompted.
            Start driving normally.

            3. Pothole Alert (Beep Sound)
            When a pothole is detected, the app will play a beep sound.
            The beep alerts the driver to slow down and drive with caution.
            Each detection is logged automatically.

            4. Location Logging
            Detected potholes are recorded with:
            GPS location, Date and time, Detection details

            5. PDF Report Generation
            Go to the Reports section.
            Select the required records or date range.
            Tap Generate PDF to create a detailed report.
            The PDF can be saved or shared.

            6. Tips for Best Performance
            Use a stable dashboard phone holder at all times.
            Ensure GPS accuracy is high before starting detection.
            Avoid rough phone movement unrelated to road conditions.

            7. Safety Notice
            For your safety, set up the app before driving. Do not interact with the app while the vehicle is in motion.
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Help & Instructions")
            .setMessage(helpText)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showAboutUsDialog() {
        val aboutText = """
            Developed by:
            Henry Nii-Armah Mettle
            Prof. Peter Appiahene
            Dr. Michael Opoku
            
            We are a technology-focused research and development team committed to improving road safety and infrastructure management through intelligent digital solutions. This Pothole Detection System is designed to automatically identify road pothole and provide real-time assistance to road users and relevant authorities.

            The system detects potholes during vehicle movement and immediately alerts drivers through an audio beep notification, enabling timely response and reducing the risk of vehicle damage or accidents. Each detected pothole is also recorded with precise GPS location, timestamp, and severity information to support monitoring and analysis.

            To enhance documentation and decision-making, the system includes automated PDF report generation, allowing detailed pothole reports to be exported for maintenance planning, inspections, academic research, and official use.

            By integrating real-time alerts, accurate geolocation, and structured reporting, this solution supports safer driving experiences, data-driven road maintenance, and smarter transportation systems.
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("About Us")
            .setMessage(aboutText)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun startMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun startGalleryAnalysisActivity() {
        val intent = Intent(this, GalleryAnalysisActivity::class.java)
        startActivity(intent)
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    }
}
